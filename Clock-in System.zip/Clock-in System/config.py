import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'mysql://root:milo1034596@localhost:3306/employee_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = True

    MAIL_SERVER = os.environ.get('MAIL_SERVER') or 'smtp.gmail.com'
    MAIL_PORT = int(os.environ.get('MAIL_PORT') or 587)
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS') is not None
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'nzpttr@gmail.com'
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'jmznigfnjefancsi'
    MAIL_DEFAULT_SENDER = ('康乃薾幼兒園系統', 'nzpttr@gmail.com')